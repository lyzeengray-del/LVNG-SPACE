\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="$ROOT/work"
OUT="$ROOT/output"
APKTOOL_VERSION="2.11.1"
mkdir -p "$WORK" "$OUT"

if ! command -v apktool >/dev/null 2>&1; then
  echo "apktool is required. Install apktool 2.11.1 or newer."
  exit 1
fi
if ! command -v apksigner >/dev/null 2>&1; then
  echo "apksigner is required (Android SDK Build Tools)."
  exit 1
fi

rm -rf "$WORK/decoded"
apktool d -f "$ROOT/original/app-debug.apk" -o "$WORK/decoded"
python3 "$ROOT/scripts/patch_apk.py" "$WORK/decoded" "$ROOT/assets/lvngx-logo.png"
apktool b "$WORK/decoded" -o "$OUT/LVNG-X-unsigned.apk"

KEY="$WORK/lvngx-debug.keystore"
if [ ! -f "$KEY" ]; then
  keytool -genkeypair -v -keystore "$KEY" -storepass android \
    -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 \
    -validity 10000 -dname "CN=LVNG-X Debug,O=Local Build,C=ID"
fi
apksigner sign --ks "$KEY" --ks-pass pass:android --key-pass pass:android \
  --out "$OUT/LVNG-X.apk" "$OUT/LVNG-X-unsigned.apk"
apksigner verify --verbose "$OUT/LVNG-X.apk"
echo "Built: $OUT/LVNG-X.apk"
