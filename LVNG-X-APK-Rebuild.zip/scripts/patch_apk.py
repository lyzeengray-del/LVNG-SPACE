\
#!/usr/bin/env python3
"""Patch an apktool-decoded APK: AISZ -> LVNG -X and replace launcher icon."""
from pathlib import Path
import re
import shutil
import sys
import xml.etree.ElementTree as ET

decoded = Path(sys.argv[1])
logo = Path(sys.argv[2])
manifest = decoded / "AndroidManifest.xml"
if not manifest.exists():
    raise SystemExit("ERROR: AndroidManifest.xml missing. Did apktool decode succeed?")

# Replace visible/source text in decoded text files (including smali and XML).
changed = 0
for p in decoded.rglob("*"):
    if not p.is_file() or p.suffix.lower() in {
        ".png", ".jpg", ".jpeg", ".webp", ".arsc", ".dex", ".so", ".jar"
    }:
        continue
    try:
        raw = p.read_bytes()
        if b"\x00" in raw:
            continue
        text = raw.decode("utf-8")
    except (UnicodeDecodeError, OSError):
        continue
    new = re.sub(r"AISZ", "LVNG -X", text, flags=re.IGNORECASE)
    if new != text:
        p.write_text(new, encoding="utf-8")
        changed += 1

# Ensure the application label resolves to the requested exact display name.
tree = ET.parse(manifest)
root = tree.getroot()
android = "{http://schemas.android.com/apk/res/android}"
app = root.find("application")
if app is None:
    raise SystemExit("ERROR: application element not found in manifest")
app.set(android + "label", "@string/app_name")
app.set(android + "icon", "@drawable/lvngx_logo")
app.set(android + "roundIcon", "@drawable/lvngx_logo")
tree.write(manifest, encoding="utf-8", xml_declaration=True)

values = decoded / "res/values"
values.mkdir(parents=True, exist_ok=True)
strings = values / "strings.xml"
if strings.exists():
    st = ET.parse(strings)
    sroot = st.getroot()
else:
    sroot = ET.Element("resources")
app_name = sroot.find("string[@name='app_name']")
if app_name is None:
    app_name = ET.SubElement(sroot, "string", {"name": "app_name"})
app_name.text = "LVNG -X"
ET.ElementTree(sroot).write(strings, encoding="utf-8", xml_declaration=True)

# Use a density-independent PNG so Android can scale it for launcher use.
icon_dir = decoded / "res/drawable-nodpi"
icon_dir.mkdir(parents=True, exist_ok=True)
shutil.copy2(logo, icon_dir / "lvngx_logo.png")

print(f"Text files changed: {changed}")
print("Application label: LVNG -X")
print("Launcher icon: res/drawable-nodpi/lvngx_logo.png")
