\
# LVNG -X — APK rebuild package

This package attempts to rebuild the supplied `app-debug.apk` after:
- replacing decoded text occurrences of `AISZ` (case-insensitive) with `LVNG -X`;
- setting the Android application label to `LVNG -X`;
- replacing the launcher icon with `assets/lvngx-logo.png`.

## Build on GitHub

1. Create a new **private** GitHub repository.
2. Upload the contents of this ZIP (keep the `.github` folder).
3. Open **Actions** → **Build LVNG-X APK** → **Run workflow**.
4. When the run finishes, open its **Artifacts** section and download `LVNG-X-APK`.

A push to the `main` branch also triggers a build.

## Local build

Requirements: Java 17, Python 3, apktool 2.11.1+, Android SDK Build Tools (`apksigner`).

```bash
bash scripts/build.sh
```

The signed APK is written to `output/LVNG-X.apk`.

## Important limitations

- An APK is compiled output, not the original Android Studio project. This package uses apktool to decode resources and DEX into smali; it does **not** recover the original Kotlin/Java source, Gradle project, comments, or original architecture.
- This is a reproducible **APK modification pipeline**, not a recovered native source project. The result may need manual fixes if the app uses resource references or obfuscated strings in unusual ways.
- Replacing `AISZ` in decoded text cannot guarantee every runtime-generated or encrypted occurrence is changed.
- The rebuilt APK is signed with a newly generated debug key. It will not update-install over the original app if the original uses a different signing key; uninstalling the old app may be required (this can remove its local data).
- Test the output on a spare device before relying on it. No successful build has been run in this environment.

Only use this package for an app you own or are authorized to modify.
